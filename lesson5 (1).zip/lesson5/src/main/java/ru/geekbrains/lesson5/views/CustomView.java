package ru.geekbrains.lesson5.views;

public class CustomView {
}
